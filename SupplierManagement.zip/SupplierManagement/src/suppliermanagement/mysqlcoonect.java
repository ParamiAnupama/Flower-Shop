package suppliermanagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;

public class mysqlcoonect {
    public static Connection connectDb() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Updated driver class name
          
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/java"); // Add your credentials
            JOptionPane.showMessageDialog(null, "Connection Established");
            
            // Debugging: Confirm database connection
            if (conn != null) {
                System.out.println("Database connection successful.");
            } else {
                System.out.println("Database connection failed.");
            }
            
            return conn;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }

    public static ObservableList<Supplier> getDataUsers() {
        ObservableList<Supplier> list = FXCollections.observableArrayList();
        Connection conn = connectDb();
        if (conn == null) {
            return list;
        }

        String query = "SELECT * FROM supplier";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Supplier(
                    rs.getInt("SID"),
                    rs.getString("SName"),
                    rs.getString("CName"),
                    rs.getString("Contacts"),
                    rs.getString("Address"),
                    rs.getString("Item"),
                    rs.getDouble("Quantity"),
                    rs.getDouble("Total")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    static Connection ConnectDb() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
