package suppliermanagement;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javafx.scene.input.MouseEvent;
import javax.swing.JOptionPane;

public class FXMLDocumentController implements Initializable {

    
    @FXML
    private TextField txt_Address;

    @FXML
    private TextField txt_CName;

    @FXML
    private TextField txt_Contacts;

    @FXML
    private TextField txt_Item;

    @FXML
    private TextField txt_Quantity;

    @FXML
    private TextField txt_SID;

    @FXML
    private TextField txt_SName;

    @FXML
    private TextField txt_Total;
    
    @FXML
    private Button add, clear, delete, update;
    @FXML
    private TableView<Supplier> table;
    @FXML
    private TableColumn<Supplier, String> Col_Address, Col_CName, Col_Contacts, Col_Item, Col_SName;
    @FXML
    private TableColumn<Supplier, Integer> Col_SID;
    @FXML
    private TableColumn<Supplier, Double> Col_Quantity, Col_Total;
    
    int index = -1;
   
    ObservableList<Supplier> listM;
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    
    public void Add_user(){
        conn = mysqlcoonect.connectDb();

        String sql="insert into supplier (SID,SName,CName,Contacts,Address,Item,Quantity,Total)values(?,?,?,?,?,?,?,?)";
        try{
            pst=conn.prepareStatement(sql);
            pst.setInt(1, Integer.parseInt(txt_SID.getText())); // SID as integer
            pst.setString(2, txt_SName.getText());
            pst.setString(3, txt_CName.getText());
            pst.setString(4, txt_Contacts.getText());
            pst.setString(5, txt_Address.getText());
            pst.setString(6, txt_Item.getText());
            pst.setDouble(7, Double.parseDouble(txt_Quantity.getText())); // Quantity as double
            pst.setDouble(8, Double.parseDouble(txt_Total.getText())); // Total as double
            pst.execute();
            
            JOptionPane.showMessageDialog(null,"User Add sucess");
            UpdateTable();
        
    }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
    }
    }
    /////methode select////
    @FXML
    void getSelected(MouseEvent event){
        index = table.getSelectionModel().getSelectedIndex();
        if (index <= -1){
            return;
        }
        Supplier selectedSupplier = table.getSelectionModel().getSelectedItem();
    
    // Set text fields with selected supplier data
    txt_SID.setText(String.valueOf(selectedSupplier.getSID()));
    txt_SName.setText(selectedSupplier.getSName());
    txt_CName.setText(selectedSupplier.getCName());
    txt_Contacts.setText(selectedSupplier.getContacts());
    txt_Address.setText(selectedSupplier.getAddress());
    txt_Item.setText(selectedSupplier.getItem());
    txt_Quantity.setText(String.valueOf(selectedSupplier.getQuantity()));
    txt_Total.setText(String.valueOf(selectedSupplier.getTotal()));
    }
   public void Edit() {
    try {
        conn = mysqlcoonect.connectDb();
        
        String sql = "UPDATE supplier SET SName = ?, CName = ?, Contacts = ?, Address = ?, Item = ?, Quantity = ?, Total = ? WHERE SID = ?";
        
        pst = conn.prepareStatement(sql);
        pst.setString(1, txt_SName.getText());               // SName as String
        pst.setString(2, txt_CName.getText());               // CName as String
        pst.setString(3, txt_Contacts.getText());            // Contacts as String
        pst.setString(4, txt_Address.getText());             // Address as String
        pst.setString(5, txt_Item.getText());                // Item as String
        pst.setDouble(6, Double.parseDouble(txt_Quantity.getText()));  // Quantity as double
        pst.setDouble(7, Double.parseDouble(txt_Total.getText()));     // Total as double
        pst.setInt(8, Integer.parseInt(txt_SID.getText()));  // SID as integer
        
        pst.executeUpdate();
        JOptionPane.showMessageDialog(null, "Update Successful");
        UpdateTable();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
}
   public void Delete(){
    conn = mysqlcoonect.connectDb();
    String sql = "delete from supplier where SID = ?";
    try {
        pst = conn.prepareStatement(sql);
        pst.setInt(1, Integer.parseInt(txt_SID.getText())); // Corrected to integer
        pst.execute();
        JOptionPane.showMessageDialog(null, "Deleted successfully");
        UpdateTable();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
}
   
   public void UpdateTable(){
        Col_SID.setCellValueFactory(new PropertyValueFactory<>("SID"));
        Col_SName.setCellValueFactory(new PropertyValueFactory<>("SName"));
        Col_CName.setCellValueFactory(new PropertyValueFactory<>("CName"));
        Col_Contacts.setCellValueFactory(new PropertyValueFactory<>("Contacts"));
        Col_Address.setCellValueFactory(new PropertyValueFactory<>("Address"));
        Col_Item.setCellValueFactory(new PropertyValueFactory<>("Item"));
        Col_Quantity.setCellValueFactory(new PropertyValueFactory<>("Quantity"));
        Col_Total.setCellValueFactory(new PropertyValueFactory<>("Total"));

        listM = mysqlcoonect.getDataUsers();
        
        // Debugging: Check if data is loaded into the ObservableList
        System.out.println("List size after data load: " + listM.size());
        
        table.setItems(listM);
        table.refresh();
   }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        UpdateTable();
    }

    public void close() {
        System.exit(0);
    }
}
