/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package suppliermanagement;

/**
 *
 * @author M C S
 */
public class Supplier {
    private int SID;
    private String SName, CName, Contacts, Address, Item;
    private double Quantity, Total;

    public Supplier(int SID, String SName, String CName, String Contacts, String Address, String Item, double Quantity, double Total) {
        this.SID = SID;
        this.SName = SName;
        this.CName = CName;
        this.Contacts = Contacts;
        this.Address = Address;
        this.Item = Item;
        this.Quantity = Quantity;
        this.Total = Total;
    }

    public int getSID() { return SID; }
    public String getSName() { return SName; }
    public String getCName() { return CName; }
    public String getContacts() { return Contacts; }
    public String getAddress() { return Address; }
    public String getItem() { return Item; }
    public double getQuantity() { return Quantity; }
    public double getTotal() { return Total; }

    public void setSID(int SID) { this.SID = SID; }
    public void setSName(String SName) { this.SName = SName; }
    public void setCName(String CName) { this.CName = CName; }
    public void setContacts(String Contacts) { this.Contacts = Contacts; }
    public void setAddress(String Address) { this.Address = Address; }
    public void setItem(String Item) { this.Item = Item; }
    public void setQuantity(double Quantity) { this.Quantity = Quantity; }
    public void setTotal(double Total) { this.Total = Total; }
}
