package tinyb;

import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;

public class SigninController implements Initializable {

     @FXML
    private Hyperlink create_acc;

    @FXML
    private Hyperlink login_acc;

    @FXML
    private Button login_btn;

    @FXML
    private AnchorPane login_form;

    @FXML
    private AnchorPane login_formp;

    @FXML
    private Label logo_b;

    @FXML
    private Label logo_b1;

    @FXML
    private Label logo_t;

    @FXML
    private Label logo_t1;

    @FXML
    private PasswordField password;

    @FXML
    private Button signup_btn;

    @FXML
    private AnchorPane signup_form;

    @FXML
    private AnchorPane signup_formp;

    @FXML
    private TextField su_email;

    @FXML
    private PasswordField su_password;

    @FXML
    private TextField su_username;

    @FXML
    private TextField username;
    
    @FXML
    private TextField su_usertype;

    private Connection connect;
    private PreparedStatement statement;
    private ResultSet result;

    // Database connection method
    public Connection connectDb() {
        try {
            connect = DriverManager.getConnection("jdbc:mysql://localhost/java", "root", "");
            System.out.println("Database connected successfully");
            return connect;
        } catch (Exception e) {
            e.printStackTrace();
            showErrorAlert("Database connection failed", "Please check your database connection settings.");
        }
        return null;
    }

    // Login method with debugging information
    public void login(ActionEvent event) {
        connect = connectDb();

        if (connect == null) {
            showErrorAlert("Database Connection Error", "Unable to connect to the database.");
            return;
        }

        try {
            // Debugging: print entered username and password (temporarily bypass hashing)
            String enteredPassword = password.getText();
            System.out.println("Entered Username: " + username.getText());
            System.out.println("Entered Password: " + enteredPassword);

            // SQL statement to check credentials
            String sql = "SELECT * FROM data WHERE username = ? and password = ?";
            statement = connect.prepareStatement(sql);
            statement.setString(1, username.getText());

            // TEMPORARILY disable hashing for testing; use enteredPassword directly
            statement.setString(2, enteredPassword);

            // Uncomment the following lines to re-enable hashing after testing
            // String hashedPassword = hashPassword(enteredPassword);
            // System.out.println("Hashed Password: " + hashedPassword);
            // statement.setString(2, hashedPassword);

            result = statement.executeQuery();
            System.out.println("SQL Query Executed");

            if (result.next()) {
                showInfoAlert("Welcome!", "Login Successful");

                // Hide the current window
                login_btn.getScene().getWindow().hide();

                // Load the Dashboard
                try {
                    Parent root = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
                    Scene scene = new Scene(root);
                    Stage stage = new Stage();
                    stage.setScene(scene);
                    stage.setTitle("Dashboard");
                    stage.show();
                } catch (Exception e) {
                    showErrorAlert("FXML Loading Error", "Unable to load the dashboard.fxml file.");
                    e.printStackTrace();
                }
            } else {
                showErrorAlert("Login Failed", "Wrong username or password.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (result != null) result.close();
                if (statement != null) statement.close();
                if (connect != null) connect.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Password hashing method using SHA-256
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Method to display error alerts
    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Method to display informational alerts
    private void showInfoAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public void signup(ActionEvent event){
        
        connect= connectDb();
        try{
            String sql = "INSERT INTO data VALUES (?,?,?,?)";
            
            statement = connect.prepareStatement(sql);
            statement.setString(1, su_username.getText());
            statement.setString(2, su_password.getText());
            statement.setString(3, su_email.getText());
            statement.setString(4, su_usertype.getText());
            
            
            statement.execute();
            
             showInfoAlert("Account created Successfully", "Welcome to Tiny Blossom");
            
            
        }catch(Exception e){e.printStackTrace();}
        
        
    }
    
    public void changeForm(ActionEvent event){
        if (event.getSource() == login_acc){
            signup_form.setVisible(false);
             signup_formp.setVisible(false);
             login_form.setVisible(true);
             login_formp.setVisible(true);
        }else if (event.getSource()== create_acc){
            signup_form.setVisible(true);
             signup_formp.setVisible(true);
             login_form.setVisible(false);
             login_formp.setVisible(false);
            
        }
    }
   
   

    public void exit() {
        System.exit(0);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
      
    }
}